document
  .getElementById("contact-form")
  .addEventListener("submit", function (e) {
    e.preventDefault(); // Evita o envio padrão do formulário

    // Coleta os dados do formulário
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;

    // Substitua o 'YOUR_FORMSPREE_ENDPOINT' pelo URL fornecido pelo Formspree após a configuração
    const formUrl = "https://formspree.io/YOUR_FORMSPREE_ENDPOINT";

    // Configuração da requisição
    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ name, email, message }),
    };

    // Envia a requisição
    fetch(formUrl, requestOptions)
      .then((response) => {
        if (response.ok) {
          alert("Mensagem enviada com sucesso!");
          document.getElementById("contact-form").reset();
        } else {
          alert(
            "Ocorreu um erro ao enviar a mensagem. Por favor, tente novamente mais tarde."
          );
        }
      })
      .catch((error) => {
        console.error("Erro:", error);
        alert(
          "Ocorreu um erro ao enviar a mensagem. Por favor, tente novamente mais tarde."
        );
      });
  });
