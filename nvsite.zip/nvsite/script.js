fetch("https://tccfast-production.up.railway.app/usuarios").then((res) =>
  console.log(res)
);
