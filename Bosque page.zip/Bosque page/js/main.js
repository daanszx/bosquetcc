function validateRegistrationForm() {
    var nome = document.getElementById('txtNome').value;
    var email = document.getElementById('txtEmail').value;
    var telefone = document.getElementById('txtTelefone').value;
    var senha = document.getElementById('txtSenha').value;
    var confirmacaoSenha = document.getElementById('txtConfirmacaoSenha').value;

    if (nome.trim() === '') {
        alert('Por favor, insira seu nome.');
        return;
    }

    if (email.trim() === '') {
        alert('Por favor, insira um endereço de e-mail.');
        return;
    }

    if (telefone.trim() === '') {
        alert('Por favor, insira seu telefone.');
        return;
    }

    if (senha.trim() === '') {
        alert('Por favor, insira uma senha.');
        return;
    }

    if (confirmacaoSenha.trim() === '') {
        alert('Por favor, confirme sua senha.');
        return;
    }

    if (senha !== confirmacaoSenha) {
        alert('As senhas não coincidem. Por favor, verifique.');
        return;
    }

    

    // If all fields are valid, proceed with the registration action
    window.location.href = '/confirmarcadastro.html';
}
